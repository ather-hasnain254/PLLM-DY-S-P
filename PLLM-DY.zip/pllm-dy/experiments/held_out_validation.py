"""
Held-Out (Leave-One-Out Cross-Validated) Predictive Error (Priority-2 item)
=============================================================================
experiments/sensitivity_analysis.py already reports how much R1-R4's fitted
COEFFICIENTS shift under leave-one-out refitting, and the resulting shift in
a PREDICTION at one fixed representative operating point. That is a
sensitivity analysis of the fit, not a held-out validation of it.

This script runs the complementary, distinct check: true leave-one-out
cross-validated (LOOCV) predictive error. For each of the n real data
points of R1-R4, refit the model on the OTHER n-1 points only, then measure
the squared error of that refit model's prediction AT the held-out point's
own covariates. Averaging over all n folds gives an honest estimate of
out-of-sample predictive error, directly comparable to the in-sample fit
loss already reported in results/calibration_results.json -- if LOOCV error
is much larger than in-sample loss, that is evidence of overfitting at this
sample size; if comparable, the fit is not simply memorizing the n points.

Uses the same real data points and model specification as
experiments/baseline_and_ablation.py (which reconstructs them identically
from experiments/calibrate_from_datasets.py). R4 is included for
completeness but, as noted there, its 8 points share one covariate value,
so LOOCV there measures only how the fitted constant moves when one of the
8 replicate measurements is withheld, not genuine covariate generalization.
R5 is excluded (threshold/clustering rule, not a point-wise regression).
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from scipy.optimize import minimize

from src.dataset_loader import load_all_datasets
from src.derivation_rules import sigmoid
from src.utils import print_header, print_section, save_results

from experiments.baseline_and_ablation import (
    r1_points, r2_points, r3_points, r4_points, linear_combo, RULE_SPECS,
)


def fit_logistic(points, ridge_lambda, x0):
    def loss(params):
        total = 0.0
        for (tau, phi, r, _), target in points:
            pred = sigmoid(linear_combo(params, tau, phi, r))
            total += (pred - target) ** 2
        total += ridge_lambda * sum(p ** 2 for p in params)
        return total

    result = minimize(loss, x0=x0, method='Nelder-Mead',
                       options={"maxiter": 5000, "xatol": 1e-8, "fatol": 1e-10})
    return result.x


def loocv_predictive_error(points, ridge_lambda, x0):
    n = len(points)
    sq_errors = []
    for i in range(n):
        train = points[:i] + points[i + 1:]
        (tau, phi, r, _), target = points[i]
        params = fit_logistic(train, ridge_lambda, x0)
        pred = sigmoid(linear_combo(params, tau, phi, r))
        sq_errors.append((pred - target) ** 2)
    mse = float(np.mean(sq_errors))
    sse = float(np.sum(sq_errors))
    return mse, sse, [float(e) for e in sq_errors]


def in_sample_loss(points, ridge_lambda, x0):
    params = fit_logistic(points, ridge_lambda, x0)
    sse = sum(
        (sigmoid(linear_combo(params, tau, phi, r)) - target) ** 2
        for (tau, phi, r, _), target in points
    )
    return float(sse)


def main():
    print_header("Held-Out (LOOCV) Predictive Error")
    cal_data = load_all_datasets()
    # Fail loudly if the raw datasets are missing (data/ is not shipped in the
    # artifact; see README "Dataset Requirements"): never overwrite saved
    # results with empty-data output.
    _need = {"R1": len(cal_data.jailbreak_success_by_model) if hasattr(cal_data, "jailbreak_success_by_model") else 0,
             "R2": len(cal_data.ipi_success_rate_by_model) if hasattr(cal_data, "ipi_success_rate_by_model") else 0}
    if _need["R2"] == 0:
        sys.exit("ERROR: datasets not found (run scripts/download_datasets.py first). "
                 "Refusing to overwrite results with empty-data output.")

    results = {}
    for rule, spec in RULE_SPECS.items():
        print_section(f"Rule {rule}")
        points = spec["points_fn"](cal_data)
        n = len(points)

        in_sample = in_sample_loss(points, spec["ridge_lambda"], spec["x0"])
        loocv_mse, loocv_sse, per_fold = loocv_predictive_error(
            points, spec["ridge_lambda"], spec["x0"])

        print(f"  n = {n}")
        print(f"  in-sample SSE (all {n} points):        {in_sample:.4f}")
        print(f"  LOOCV total SSE (held-out predictions): {loocv_sse:.4f}")
        print(f"  LOOCV mean squared error per fold:      {loocv_mse:.4f}")
        print(f"  ratio (LOOCV SSE / in-sample SSE):      {loocv_sse / in_sample if in_sample > 0 else float('nan'):.2f}x")

        results[rule] = {
            "n": n,
            "in_sample_sse": in_sample,
            "loocv_total_sse": loocv_sse,
            "loocv_mean_sq_error": loocv_mse,
            "per_fold_sq_error": per_fold,
        }

    save_results(results, "held_out_validation_results.json")
    print_section("Done")
    print("  Full results written to results/held_out_validation_results.json")


if __name__ == "__main__":
    main()
