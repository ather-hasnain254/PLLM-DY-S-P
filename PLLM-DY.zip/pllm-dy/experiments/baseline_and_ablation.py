"""
Baseline Comparison and Functional-Form Ablation (Priority-2 roadmap items)
=============================================================================
Two related analyses, both run against the SAME real calibration points
already used in experiments/calibrate_from_datasets.py (reconstructed
identically here -- same model/covariate mappings, same sources):

  1. BASELINE: a constant-rate model (one free parameter: a single
     success probability p, independent of theta/attack covariates)
     compared against PLLM-DY's calibrated logistic model, for each of
     R1, R2, R3, R4. This tests whether the covariates (temperature,
     alignment, content/context ratio, trust) are actually doing any
     work, or whether a single constant predicts the real data just as
     well.

  2. ABLATION: the logistic functional form is compared against a
     clipped-linear form (same covariates, no sigmoid) and a probit
     form (same covariates, Phi(.) instead of sigmoid(.)), fit by the
     same least-squares objective with the same L2 ridge regularization
     used for the corresponding rule's logistic fit in
     calibrate_from_datasets.py (so the comparison is apples-to-apples,
     not an artifact of differing regularization strength).

Honesty notes (consistent with the rest of this project's calibration
code):
  - R1 has 4 real data points, R2 and R3 have 6, R4 has 8 -- all of
    these are small-N fits; squared-error differences between
    functional forms at this N should be read as suggestive, not as
    evidence of a large effect size.
  - R4's 8 real points (He et al. Table 1) all share the SAME covariate
    values (see calibrate_from_datasets.py::fit_r4_params's own
    docstring) -- there is no real per-point covariate variation to fit
    a functional *form* against, so for R4 the three "forms" are
    mathematically forced to collapse to predicting the same single
    value, differing only in which link function maps that value back
    through sigmoid/identity/Phi. We report R4's baseline/ablation
    numbers for completeness but flag this degeneracy explicitly rather
    than presenting it as a meaningful form comparison.
  - R5 is a threshold/clustering-based rule, not a continuous regression
    against a success-rate target, and is not included here.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

from src.dataset_loader import load_all_datasets
from src.derivation_rules import sigmoid
from src.utils import print_header, print_section, save_results


def probit(x):
    return norm.cdf(x)


def clipped_linear(x):
    return float(np.clip(x, 0.0, 1.0))


# ----------------------------------------------------------------------------
# Reconstruct the same real data points used in calibrate_from_datasets.py
# ----------------------------------------------------------------------------

def r1_points(cal_data):
    model_params = {
        "GPT-4":              (0.7, 0.70),
        "GPT-3.5-Turbo":      (0.7, 0.45),
        "Llama-2-7B-Chat":    (0.6, 0.55),
        "Vicuna-13B":         (0.7, 0.25),
    }
    pts = []
    for model, rate in cal_data.jailbreak_success_rates.items():
        if model in model_params:
            tau, phi = model_params[model]
            pts.append(((tau, phi, 0.0, 0.0), rate))  # (tau, phi, r, unused), target
    return pts


def r2_points(cal_data):
    model_map = {
        "GPT-4-ReAct":              (0.7, 0.70, 0.15),
        "GPT-3.5-ReAct":            (0.7, 0.45, 0.15),
        "Claude-2-ReAct":           (0.7, 0.75, 0.15),
        "Llama2-70B-ReAct":         (0.6, 0.55, 0.15),
        "GPT-4-FunctionCalling":    (0.7, 0.70, 0.10),
        "GPT-3.5-FunctionCalling":  (0.7, 0.45, 0.10),
    }
    pts = []
    for model, rate in cal_data.ipi_success_rate_by_model.items():
        if model in model_map:
            tau, phi, r = model_map[model]
            pts.append(((tau, phi, r, 0.0), rate))
    return pts


def r3_points(cal_data):
    data = [
        (0.0, 0.000), (0.5, 0.356), (1.0, 0.533),
        (0.0, 0.190), (0.5, 0.310), (1.0, 0.630),
    ]
    tau, phi = 0.7, 0.7
    return [((tau, phi, r, 0.0), asr) for r, asr in data]


def r4_points(cal_data):
    he_asr = [0.931, 0.817, 0.876, 0.774, 0.952, 0.976, 0.969, 0.985]
    tau, trust = 0.7, 0.85
    # Use the same (tau, trust) slot layout as the others: (tau, phi=trust, r=0, unused)
    return [((tau, trust, 0.0, 0.0), target) for target in he_asr]


RULE_SPECS = {
    "R1": {"points_fn": r1_points, "ridge_lambda": 0.002, "x0": [2.5, 3.0, -0.5, 0.0]},
    "R2": {"points_fn": r2_points, "ridge_lambda": 0.001, "x0": [1.8, 2.5, -1.0, 4.0]},
    "R3": {"points_fn": r3_points, "ridge_lambda": 0.0,   "x0": [1.5, 2.0, -1.5, 5.0]},
    "R4": {"points_fn": r4_points, "ridge_lambda": 0.0,   "x0": [1.0, 0.0, -0.5, 0.0]},
}


def linear_combo(params, tau, phi, r):
    a, b, c, d = params
    return a * tau - b * phi + d * r + c


def fit_form(points, link_fn, ridge_lambda, x0):
    def loss(params):
        total = 0.0
        for (tau, phi, r, _), target in points:
            x = linear_combo(params, tau, phi, r)
            pred = link_fn(x)
            total += (pred - target) ** 2
        total += ridge_lambda * sum(p ** 2 for p in params)
        return total

    result = minimize(loss, x0=x0, method='Nelder-Mead',
                       options={"maxiter": 5000, "xatol": 1e-8, "fatol": 1e-10})
    params = result.x
    # Report UNREGULARIZED squared error (comparable across forms/baseline)
    unreg = sum(
        (link_fn(linear_combo(params, tau, phi, r)) - target) ** 2
        for (tau, phi, r, _), target in points
    )
    return params, float(unreg)


def fit_constant_baseline(points):
    targets = [t for _, t in points]
    p_hat = float(np.mean(targets))
    loss = float(sum((p_hat - t) ** 2 for t in targets))
    return p_hat, loss


def main():
    print_header("Baseline Comparison and Functional-Form Ablation")
    cal_data = load_all_datasets()
    # Fail loudly if the raw datasets are missing (data/ is not shipped in the
    # artifact; see README "Dataset Requirements"): never overwrite saved
    # results with empty-data output.
    _need = {"R1": len(cal_data.jailbreak_success_by_model) if hasattr(cal_data, "jailbreak_success_by_model") else 0,
             "R2": len(cal_data.ipi_success_rate_by_model) if hasattr(cal_data, "ipi_success_rate_by_model") else 0}
    if _need["R2"] == 0:
        sys.exit("ERROR: datasets not found (run scripts/download_datasets.py first). "
                 "Refusing to overwrite results with empty-data output.")

    results = {}
    for rule, spec in RULE_SPECS.items():
        print_section(f"Rule {rule}")
        points = spec["points_fn"](cal_data)
        n = len(points)

        p_hat, baseline_loss = fit_constant_baseline(points)

        logistic_params, logistic_loss = fit_form(
            points, sigmoid, spec["ridge_lambda"], spec["x0"])
        linear_params, linear_loss = fit_form(
            points, clipped_linear, spec["ridge_lambda"], spec["x0"])
        probit_params, probit_loss = fit_form(
            points, probit, spec["ridge_lambda"], spec["x0"])

        print(f"  n = {n} real data points")
        print(f"  constant-rate baseline: p_hat={p_hat:.4f}  SSE={baseline_loss:.4f}")
        print(f"  logistic form:          SSE={logistic_loss:.4f}")
        print(f"  clipped-linear form:    SSE={linear_loss:.4f}")
        print(f"  probit form:            SSE={probit_loss:.4f}")

        results[rule] = {
            "n": n,
            "ridge_lambda": spec["ridge_lambda"],
            "constant_baseline": {"p_hat": p_hat, "sse": baseline_loss},
            "logistic": {"params": logistic_params.tolist(), "sse": logistic_loss},
            "clipped_linear": {"params": linear_params.tolist(), "sse": linear_loss},
            "probit": {"params": probit_params.tolist(), "sse": probit_loss},
        }

    save_results(results, "baseline_and_ablation_results.json")
    print_section("Done")
    print("  Full results written to results/baseline_and_ablation_results.json")


if __name__ == "__main__":
    main()
