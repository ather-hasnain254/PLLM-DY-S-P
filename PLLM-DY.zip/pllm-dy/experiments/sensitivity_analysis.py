"""
Sensitivity / Robustness Analysis for R1-R5 Calibrated Coefficients
=====================================================================
Addresses Priority-1 review item: "Add sensitivity/robustness analysis
for fitted coefficients."

Method: leave-one-out (jackknife) refitting for R1-R4, since each of
these rules is fit against a very small number of real data points
(4, 6, 6, and 8 respectively) -- too few for bootstrap-with-replacement
to be meaningful (resampling 4 points with replacement routinely
produces degenerate samples with 1-2 distinct points). Leave-one-out is
the standard small-N robustness check: refit N times, each time
dropping one real empirical data point, and report how much the fitted
coefficients and the resulting epsilon-bounds move.

R5's threshold is instead bootstrapped by resampling the 143 real DAN
community cluster sizes with replacement (B=2000 resamples), since N=143
is large enough for bootstrap resampling to be meaningful there.

This script does NOT invent new data points or alter any of the real
source numbers already verified in calibrate_from_datasets.py; it only
removes one real point at a time (R1-R4) or resamples the real per-
community sizes (R5) and re-runs the exact same fitting procedure already
used for the reported point estimate.

Run after: python experiments/calibrate_from_datasets.py
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import numpy as np
from scipy.optimize import minimize

from src.derivation_rules import sigmoid
from src.dataset_loader import load_all_datasets
from src.utils import print_header, print_section, save_results


# ---------------------------------------------------------------------------
# Re-declare the real data points used by calibrate_from_datasets.py's
# fit_r1/r2/r3/r4_params, so leave-one-out subsets can be built from them.
# These are copied verbatim from calibrate_from_datasets.py (same source
# citations, same numbers) -- not re-derived or altered here.
# ---------------------------------------------------------------------------

R1_MODEL_PARAMS = {
    "GPT-4":              (0.7, 0.70),
    "GPT-3.5-Turbo":      (0.7, 0.45),
    "Llama-2-7B-Chat":    (0.6, 0.55),
    "Vicuna-13B":         (0.7, 0.25),
}
R1_RIDGE_LAMBDA = 0.002

R2_MODEL_MAP = {
    "GPT-4-ReAct":              (0.7, 0.70, 0.15),
    "GPT-3.5-ReAct":            (0.7, 0.45, 0.15),
    "Claude-2-ReAct":           (0.7, 0.75, 0.15),
    "Llama2-70B-ReAct":         (0.6, 0.55, 0.15),
    "GPT-4-FunctionCalling":    (0.7, 0.70, 0.10),
    "GPT-3.5-FunctionCalling":  (0.7, 0.45, 0.10),
}
R2_RIDGE_LAMBDA = 0.001

R3_DATA = [
    (0.0, 0.000, "Agent-E privacy-exfiltration, non-contextual"),
    (0.5, 0.356, "Agent-E privacy-exfiltration, task-aligned"),
    (1.0, 0.533, "Agent-E privacy-exfiltration, context-chained"),
    (0.0, 0.190, "Browser-use task-completion, non-contextual"),
    (0.5, 0.310, "Browser-use task-completion, task-aligned"),
    (1.0, 0.630, "Browser-use task-completion, context-chained"),
]

R4_DATA = [0.931, 0.817, 0.876, 0.774, 0.952, 0.976, 0.969, 0.985]


def fit_r1_subset(points):
    def loss(params):
        a, b, c = params
        total = sum((sigmoid(a * tau - b * phi + c) - target) ** 2
                    for tau, phi, target in points)
        total += R1_RIDGE_LAMBDA * (a ** 2 + b ** 2 + c ** 2)
        return total
    result = minimize(loss, x0=[2.5, 3.0, -0.5], method='Nelder-Mead')
    return result.x  # a, b, c


def fit_r2_subset(points):
    def loss(params):
        a, b, c, d = params
        total = sum((sigmoid(a * tau - b * phi + d * r + c) - target) ** 2
                    for tau, phi, r, target in points)
        total += R2_RIDGE_LAMBDA * (a ** 2 + b ** 2 + c ** 2 + d ** 2)
        return total
    result = minimize(loss, x0=[1.8, 2.5, -1.0, 4.0], method='Nelder-Mead')
    return result.x  # a, b, c, d


def fit_r3_subset(points):
    def loss(params):
        a, b, c, d = params
        total = sum((sigmoid(a * tau - b * phi + d * r + c) - target) ** 2
                    for tau, phi, r, target in points)
        return total
    result = minimize(loss, x0=[1.5, 2.0, -1.5, 5.0], method='Nelder-Mead')
    return result.x  # a, b, c, d


def fit_r4_subset(values, trust_fixed=0.85, tau_fixed=0.7):
    def loss(params):
        a, b, t = params
        total = sum((sigmoid(t * trust_fixed + a * tau_fixed + b) - target) ** 2
                    for target in values)
        return total
    result = minimize(loss, x0=[1.0, -0.5, 3.0], method='Nelder-Mead')
    return result.x  # a, b, t


def jackknife_r1():
    points = [(tau, phi, None) for tau, phi in R1_MODEL_PARAMS.values()]
    # Pair each model's (tau, phi) with its real rate via the same dict
    # used in calibrate_from_datasets.py; rates are re-loaded from the
    # real calibration pipeline so no number is hand-typed here.
    cal = load_all_datasets()
    model_rate = cal.jailbreak_success_rates
    full_points = []
    for model, (tau, phi) in R1_MODEL_PARAMS.items():
        if model in model_rate:
            full_points.append((tau, phi, model_rate[model], model))
    results = {"full_fit": None, "leave_one_out": []}
    full = [(t, p, r) for t, p, r, _ in full_points]
    a, b, c = fit_r1_subset(full)
    results["full_fit"] = {"a": float(a), "b": float(b), "c": float(c), "n": len(full)}
    for i, (t, p, r, name) in enumerate(full_points):
        subset = [(t2, p2, r2) for j, (t2, p2, r2) in enumerate(full) if j != i]
        a_i, b_i, c_i = fit_r1_subset(subset)
        results["leave_one_out"].append({
            "dropped": name, "a": float(a_i), "b": float(b_i), "c": float(c_i)
        })
    return results


def jackknife_r2():
    cal = load_all_datasets()
    model_rate = cal.ipi_success_rate_by_model
    full_points = []
    for model, (tau, phi, r) in R2_MODEL_MAP.items():
        if model in model_rate:
            full_points.append((tau, phi, r, model_rate[model], model))
    results = {"full_fit": None, "leave_one_out": []}
    full = [(t, p, rr, rate) for t, p, rr, rate, _ in full_points]
    a, b, c, d = fit_r2_subset(full)
    results["full_fit"] = {"a": float(a), "b": float(b), "c": float(c), "d": float(d), "n": len(full)}
    for i, (t, p, rr, rate, name) in enumerate(full_points):
        subset = [pt for j, pt in enumerate(full) if j != i]
        a_i, b_i, c_i, d_i = fit_r2_subset(subset)
        results["leave_one_out"].append({
            "dropped": name, "a": float(a_i), "b": float(b_i),
            "c": float(c_i), "d": float(d_i)
        })
    return results


def jackknife_r3():
    tau_fixed, phi_fixed = 0.7, 0.7
    full = [(tau_fixed, phi_fixed, r, asr) for r, asr, _ in R3_DATA]
    results = {"full_fit": None, "leave_one_out": []}
    a, b, c, d = fit_r3_subset(full)
    results["full_fit"] = {"a": float(a), "b": float(b), "c": float(c), "d": float(d), "n": len(full)}
    for i in range(len(R3_DATA)):
        subset = [pt for j, pt in enumerate(full) if j != i]
        a_i, b_i, c_i, d_i = fit_r3_subset(subset)
        results["leave_one_out"].append({
            "dropped": R3_DATA[i][2], "a": float(a_i), "b": float(b_i),
            "c": float(c_i), "d": float(d_i)
        })
    return results


def jackknife_r4():
    results = {"full_fit": None, "leave_one_out": []}
    a, b, t = fit_r4_subset(R4_DATA)
    results["full_fit"] = {"a": float(a), "b": float(b), "t": float(t), "n": len(R4_DATA)}
    for i in range(len(R4_DATA)):
        subset = [v for j, v in enumerate(R4_DATA) if j != i]
        a_i, b_i, t_i = fit_r4_subset(subset)
        results["leave_one_out"].append({
            "dropped_value": R4_DATA[i], "a": float(a_i), "b": float(b_i), "t": float(t_i)
        })
    return results


def bootstrap_r5(n_boot=2000, seed=42):
    cal = load_all_datasets()
    categories = cal.dan_prompt_categories
    multi_prompt_cats = {k: v for k, v in categories.items() if v >= 2}
    cluster_sizes = np.array(list(multi_prompt_cats.values()), dtype=float)
    n = len(cluster_sizes)
    rng = np.random.default_rng(seed)

    def threshold_from_sizes(sizes):
        avg = np.mean(sizes)
        return max(0.70, min(0.90, 1.0 - 0.05 * np.log(avg + 1)))

    point_estimate = threshold_from_sizes(cluster_sizes)
    boot_thresholds = []
    for _ in range(n_boot):
        resample = rng.choice(cluster_sizes, size=n, replace=True)
        boot_thresholds.append(threshold_from_sizes(resample))
    boot_thresholds = np.array(boot_thresholds)
    return {
        "point_estimate": float(point_estimate),
        "n_communities": int(n),
        "bootstrap_mean": float(np.mean(boot_thresholds)),
        "bootstrap_std": float(np.std(boot_thresholds)),
        "bootstrap_ci95": [float(np.percentile(boot_thresholds, 2.5)),
                           float(np.percentile(boot_thresholds, 97.5))],
        "n_bootstrap": n_boot,
    }


def summarize_spread(loo_list, keys):
    """Report min/max/range across leave-one-out refits for each coefficient."""
    out = {}
    for k in keys:
        vals = [d[k] for d in loo_list]
        out[k] = {
            "min": float(min(vals)), "max": float(max(vals)),
            "range": float(max(vals) - min(vals)),
            "std": float(np.std(vals)),
        }
    return out


def epsilon_shift_r1(full_fit, loo_list, tau=0.7, phi=0.7):
    """How much does R1's predicted success rate at a fixed (tau,phi) move
    across leave-one-out refits, relative to the full-data fit?"""
    base = sigmoid(full_fit["a"] * tau - full_fit["b"] * phi + full_fit["c"])
    shifts = []
    for d in loo_list:
        pred = sigmoid(d["a"] * tau - d["b"] * phi + d["c"])
        shifts.append(abs(pred - base))
    return {"base_prediction": float(base), "max_abs_shift": float(max(shifts)),
            "mean_abs_shift": float(np.mean(shifts))}


def epsilon_shift_r2(full_fit, loo_list, tau=0.7, phi=0.7, r=0.15):
    base = sigmoid(full_fit["a"] * tau - full_fit["b"] * phi + full_fit["d"] * r + full_fit["c"])
    shifts = []
    for d in loo_list:
        pred = sigmoid(d["a"] * tau - d["b"] * phi + d["d"] * r + d["c"])
        shifts.append(abs(pred - base))
    return {"base_prediction": float(base), "max_abs_shift": float(max(shifts)),
            "mean_abs_shift": float(np.mean(shifts))}


def main():
    print_header("Sensitivity / Robustness Analysis: R1-R5 Calibrated Coefficients")

    print_section("R1 (f_DPI): leave-one-out over 4 real JailbreakBench points")
    r1 = jackknife_r1()
    r1_spread = summarize_spread(r1["leave_one_out"], ["a", "b", "c"])
    r1_eps = epsilon_shift_r1(r1["full_fit"], r1["leave_one_out"])
    print(f"  Full fit: {r1['full_fit']}")
    for d in r1["leave_one_out"]:
        print(f"    drop {d['dropped']:20s} -> a={d['a']:.3f} b={d['b']:.3f} c={d['c']:.3f}")
    print(f"  Coefficient spread: {r1_spread}")
    print(f"  Prediction shift at (tau=0.7,phi=0.7): {r1_eps}")

    print_section("R2 (f_IPI): leave-one-out over 6 real InjecAgent points")
    r2 = jackknife_r2()
    r2_spread = summarize_spread(r2["leave_one_out"], ["a", "b", "c", "d"])
    r2_eps = epsilon_shift_r2(r2["full_fit"], r2["leave_one_out"])
    print(f"  Full fit: {r2['full_fit']}")
    for d in r2["leave_one_out"]:
        print(f"    drop {d['dropped']:25s} -> a={d['a']:.3f} b={d['b']:.3f} c={d['c']:.3f} d={d['d']:.3f}")
    print(f"  Coefficient spread: {r2_spread}")
    print(f"  Prediction shift at (tau=0.7,phi=0.7,r=0.15): {r2_eps}")

    print_section("R3 (f_CP): leave-one-out over 6 real web-agent points")
    r3 = jackknife_r3()
    r3_spread = summarize_spread(r3["leave_one_out"], ["a", "b", "c", "d"])
    print(f"  Full fit: {r3['full_fit']}")
    for d in r3["leave_one_out"]:
        print(f"    drop {d['dropped'][:40]:40s} -> a={d['a']:.3f} b={d['b']:.3f} c={d['c']:.3f} d={d['d']:.3f}")
    print(f"  Coefficient spread: {r3_spread}")

    print_section("R4 (f_AC): leave-one-out over 8 real He et al. points")
    r4 = jackknife_r4()
    r4_spread = summarize_spread(r4["leave_one_out"], ["a", "b", "t"])
    print(f"  Full fit: {r4['full_fit']}")
    for d in r4["leave_one_out"]:
        print(f"    drop ASR={d['dropped_value']:.3f} -> a={d['a']:.3f} b={d['b']:.3f} t={d['t']:.3f}")
    print(f"  Coefficient spread: {r4_spread}")

    print_section("R5 (threshold): bootstrap over 143 real DAN community sizes")
    r5 = bootstrap_r5()
    print(f"  {r5}")

    results = {
        "r1": {"full_fit": r1["full_fit"], "leave_one_out": r1["leave_one_out"],
               "coefficient_spread": r1_spread, "prediction_shift": r1_eps},
        "r2": {"full_fit": r2["full_fit"], "leave_one_out": r2["leave_one_out"],
               "coefficient_spread": r2_spread, "prediction_shift": r2_eps},
        "r3": {"full_fit": r3["full_fit"], "leave_one_out": r3["leave_one_out"],
               "coefficient_spread": r3_spread},
        "r4": {"full_fit": r4["full_fit"], "leave_one_out": r4["leave_one_out"],
               "coefficient_spread": r4_spread},
        "r5": r5,
        "method_note": ("R1-R4: leave-one-out (jackknife) refitting, since each "
                        "rule's real data has only 4-8 points -- too few for "
                        "meaningful bootstrap-with-replacement. R5: bootstrap "
                        "over 143 real community cluster sizes (large enough "
                        "for resampling to be meaningful)."),
    }
    save_results(results, "sensitivity_analysis_results.json")
    print_section("Done. Results saved to results/sensitivity_analysis_results.json")


if __name__ == "__main__":
    main()
