"""
Cascade-Scale Experiment (Priority-2 roadmap item)
====================================================
Extends Case Study 2 (case_study_cascade.py) along two axes that the
original case study did not cover:

  1. Longer chains: k = 1..12 hops (the original case study only went up
     to 4 hops), under the three trust regimes already used elsewhere in
     the paper (high=0.85, medium=0.50, low=0.15).
  2. The CALIBRATED R4 parameters (a=1.034, b=-0.563, t=2.532, from
     results/calibration_results.json, He et al. Table 1, 8 real points),
     rather than the DEFAULT R4 parameters (a=1.0, b=-0.5, t=3.0) that
     case_study_cascade.py uses. This is a real difference worth
     reporting explicitly, not a silent substitution.

For each (trust regime, hop count) we report:
  - the closed-form theoretical probability p_cascade = p1 * p4^(k-1)
  - a Monte Carlo empirical estimate (num_trials=50,000) with a 95%
    Wald confidence interval, as an independent check on the closed form
  - both under DEFAULT and CALIBRATED R4 parameters, so the two can be
    compared directly.

All numbers below are computed by actually running this script; nothing
here is asserted without the corresponding Monte Carlo run completing.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import numpy as np

from src.derivation_rules import LLMParameters, AttackParameters, f_ac
from src.utils import print_header, print_section, save_results

INITIAL_PROB = 0.24  # Case Study 1's real IPI compromise probability (p_1)
MAX_HOPS = 12
NUM_TRIALS = 50_000

TRUST_REGIMES = {
    "high_trust (0.85)": 0.85,
    "medium_trust (0.50)": 0.50,
    "low_trust (0.15)": 0.15,
}

DEFAULT_R4_PARAMS = {"a": 1.0, "b": -0.5, "t": 3.0}

with open(Path(__file__).parent.parent / "results" / "calibration_results.json") as f:
    _cal = json.load(f)
CALIBRATED_R4_PARAMS = {
    "a": _cal["r4_params_calibrated"]["a"],
    "b": _cal["r4_params_calibrated"]["b"],
    "t": _cal["r4_params_calibrated"]["t"],
}


def theoretical_cascade_curve(trust: float, r4_params: dict, max_hops: int,
                               theta: LLMParameters) -> list:
    attack = AttackParameters(trust_level=trust)
    p4 = f_ac(theta, attack, params=r4_params)
    return [INITIAL_PROB * (p4 ** (k - 1)) for k in range(1, max_hops + 1)]


def monte_carlo_cascade(trust: float, r4_params: dict, hops: int,
                        theta: LLMParameters, num_trials: int,
                        rng: np.random.Generator) -> dict:
    """
    Direct Monte Carlo simulation of a single (trust, hop-count) cell:
    simulate `num_trials` independent cascade attempts of exactly `hops`
    hops, each hop an independent Bernoulli(p4) trial following an
    initial Bernoulli(p1) compromise, and return the empirical success
    probability with a 95% Wald CI.
    """
    attack = AttackParameters(trust_level=trust)
    p4 = f_ac(theta, attack, params=r4_params)

    successes = 0
    for _ in range(num_trials):
        if rng.random() > INITIAL_PROB:
            continue
        ok = True
        for _ in range(hops - 1):
            if rng.random() > p4:
                ok = False
                break
        if ok:
            successes += 1

    p_hat = successes / num_trials
    se = (p_hat * (1 - p_hat) / num_trials) ** 0.5
    ci95 = 1.96 * se
    return {
        "p4": float(p4),
        "theoretical": float(INITIAL_PROB * (p4 ** (hops - 1))),
        "empirical": float(p_hat),
        "ci95": float(ci95),
        "num_trials": num_trials,
    }


def main():
    print_header("Cascade-Scale Experiment (Priority-2 roadmap item)")
    theta = LLMParameters("default", temperature=0.7, alignment_robustness=0.7)
    rng = np.random.default_rng(42)

    report_hops = [2, 3, 4, 6, 8, 10, 12]
    results = {
        "initial_prob": INITIAL_PROB,
        "num_trials": NUM_TRIALS,
        "default_r4_params": DEFAULT_R4_PARAMS,
        "calibrated_r4_params": CALIBRATED_R4_PARAMS,
        "regimes": {},
    }

    for label, trust in TRUST_REGIMES.items():
        print_section(label)
        results["regimes"][label] = {"default": {}, "calibrated": {}}
        for tag, r4p in [("default", DEFAULT_R4_PARAMS),
                         ("calibrated", CALIBRATED_R4_PARAMS)]:
            print(f"  [{tag} R4 params]")
            for hops in report_hops:
                cell = monte_carlo_cascade(trust, r4p, hops, theta, NUM_TRIALS, rng)
                results["regimes"][label][tag][str(hops)] = cell
                print(f"    hops={hops:2d}: theory={cell['theoretical']:.6f}  "
                      f"MC={cell['empirical']:.6f} +/- {cell['ci95']:.6f}")

    save_results(results, "cascade_scale_experiment.json")
    print_section("Done")
    print("  Full results written to results/cascade_scale_experiment.json")


if __name__ == "__main__":
    main()
